﻿class Laboratorio_7
{
    static void Main(string[] args)
    {
        //Procedimiento ejercicio uno
        int num = 0;
        bool r = false;
        Console.WriteLine("Bienvenido - Ejercicio 1");
        Console.WriteLine("\nPrograma para determinar si un numero es positivo, negativo o cero");
        Console.WriteLine("\nIngrese un numero entero:");
        num = Int32.Parse(Console.ReadLine());

        
            if (num < 0)
            {
                Console.WriteLine("\nRESULTADO: El numero ingresado NEGATIVO");
                

            }
            else if (num > 0)
            {
                Console.WriteLine("\nRESULTADO: El numero ingresado POSITIVO");
               
            }
            else if (num == 0)
            {
                Console.WriteLine("\nRESULTADO: El numero ingresado es CERO");
                
            }
            else
            {
                Console.WriteLine("\nIngrese un dato valido (el dato debe de ser un numero entero, ejemplo: 8)");
                
            }
            Console.ReadKey();
        Console.Clear();

        //Procedimiento Ejercicio 2
        
        Console.WriteLine("Bienvenido - Ejercicio 2");
        Console.WriteLine("\nIngrese numero de día \n Siendo el numero 1 el dia lunes, y el numero 7 el dia domingo");

        int dia = 0;
        dia = Int32.Parse(Console.ReadLine());

        if (dia <= 0)
        {
            Console.WriteLine("Ingrese un numero valido");
        }
        else if (dia > 7)
        {
            Console.WriteLine("Ingrese un numero valido");
        }
        else 
        { 

            switch (dia)
            {
                case 1:
                    Console.WriteLine("Dia lunes");
                    break;
                case 2:
                    Console.WriteLine("Dia martes");
                    break;
                case 3:
                    Console.WriteLine("Dia miercoles");
                    break;
                case 4:
                    Console.WriteLine("Dia jueves");
                    break;
                case 5:
                    Console.WriteLine("Dia viernes");
                    break;
                case 6:
                    Console.WriteLine("Dia sabado");
                    break;
                case 7:
                    Console.WriteLine("Dia domingo");
                    break;
            }
        
       
        }

        Console.ReadKey();

    }
}