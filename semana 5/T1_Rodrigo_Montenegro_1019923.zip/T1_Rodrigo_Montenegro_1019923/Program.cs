﻿// See https://aka.ms/new-console-template for more information
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi segundo programa");
        string sNombre, sEdad, sCarrera, sCarne;

        Console.WriteLine("\nIngrese Nombre: ");
        sNombre= Console.ReadLine();

        Console.WriteLine("\nIngrese edad: ");
        sEdad= Console.ReadLine();

        Console.WriteLine("\nIngrese que Carrera cursa: ");
        sCarrera= Console.ReadLine();

        Console.WriteLine("\nIngrese su carne: ");
        sCarne= Console.ReadLine();

        Console.WriteLine("\nNombre: "+sNombre);
        Console.WriteLine("Edad: "+sEdad);
        Console.WriteLine("Carrera: "+sCarrera);
        Console.WriteLine("Carne: "+sCarne);

        Console.WriteLine("\nSoy "+sNombre+", tengo "+sEdad+" años y estudio la carrera de "+sCarrera+"\nMi numero de carne es: "+sCarne);
        Console.ReadKey();
    }
}