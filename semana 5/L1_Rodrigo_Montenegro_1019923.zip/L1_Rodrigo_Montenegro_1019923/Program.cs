﻿class Program
{
    static void Main(string[] args)
    {

        Console.WriteLine("Hola mundo");
        Console.WriteLine("Soy Rodrigo Montengro \n");
        Console.WriteLine("Hola mundo");
        Console.WriteLine("Rodrigo Montengro \n");

        /* esto es un ejemplo de comentarios */

        Console.WriteLine("Ingrese su nombre:");
        string Nombre=Console.ReadLine();
        Console.WriteLine("Hola mundo \n");
        Console.WriteLine("soy " + Nombre+"\n");
        Console.ReadKey();
    }
}
