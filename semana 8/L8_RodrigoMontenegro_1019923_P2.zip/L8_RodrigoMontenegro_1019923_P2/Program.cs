﻿class Laboratorio_8
{
    static void Main(string[] args)
    {
        int i = 0, d = 0, b100 = 0, b50 = 0, b20 = 0, b10 = 0, b5 = 0, m1 = 0, m25 = 0, m11 = 0;

        decimal n = 0, r = 0;

        for( i = 0; i>=0; i++)
        {
            Console.WriteLine("Rodrigo Montenegro - 1019923");
            Console.WriteLine("Ingrese numero");
            n = Decimal.Parse(Console.ReadLine());


            if (n > 0 && n<1000)
            {
                if (n >= 100)
                {
                    r = n / 100;
                    b100 = Convert.ToInt32(r);
                    if (b100 > 1)
                    {
                        Console.WriteLine((b100 - 1) + " billete(s) de Q100.00");
                        n = n - ((b100 - 1) * 100);
                    }
                    else
                    {
                        Console.WriteLine(b100 + " billete(s) de Q100.00");
                        n = n - (b100 * 100);
                    }
                }
                if (n >= 50)
                {
                    r = n / 50;
                    b50 = Convert.ToInt32(r);
                    if (b50 > 1)
                    {
                        Console.WriteLine((b50 - 1) + " billete(s) de Q50.00");
                        n = n - ((b50 - 1) * 50);
                    }
                    else
                    {
                        Console.WriteLine(b50 + " billete(s) de Q50.00");
                        n = n - (b50 * 50);
                    }
                }
                        if(n >= 20)
                        {
                            r = n / 20;
                            b20 = Convert.ToInt32(r);
                            if (b20 > 1)
                            {
                                Console.WriteLine((b20 - 1) + " billete(s) de Q20.00");
                                n = n - ((b20 - 1) * 20);
                            }
                            else
                            {
                                Console.WriteLine((b20) + " billete(s) de Q20.00");
                                n = n - (b20 * 20);
                            }
                        }
                        if (n >= 10)
                        {
                            r = n / 10;
                            b10 = Convert.ToInt32(r);
                            if (b10 > 1)
                            {
                                Console.WriteLine((b10 - 1) + " billete(s) de Q10.00");
                                n = n - ((b10 - 1) * 10);
                            }
                            else
                            {
                                Console.WriteLine((b10) + " billete(s) de Q10.00");
                                n = n - (b10 * 10);
                            }
                        }if(n >= 5)
                        {
                            r = n / 5;
                            b5 = Convert.ToInt32(r);
                            if (b5 > 1)
                            {
                                Console.WriteLine((b5 - 1) + " billete(s) de Q5.00");
                                n = n - ((b5 - 1) * 5);
                            }
                            else
                            {
                                Console.WriteLine((b5) + " billete(s) de Q5.00");
                                n = n - (b5 * 5);
                            }
                        }
                        if (n >= 1)
                        {
                            r = n / 1;
                            m1 = Convert.ToInt32(r);
                            
                                Console.WriteLine((m1) + " Moneda(s) de Q1.00");
                                n = n - (m1);
                            
                        }

                        n = n * 100;

                        if (n >= 25)
                        {
                            r = n / 25;
                            m25 = Convert.ToInt32(r);
                            Console.WriteLine((m25) + " Moneda(s) de Q0.25");
                            n = n - (m25*25);
                            
                        }
                        if (n >= 1)
                        {
                            r = n / 1;
                            m11 = Convert.ToInt32(r);
                            Console.WriteLine((m11) + " Moneda(s) de Q0.01");
                            n = n - (m11);

                        }

            Console.ReadKey();
            Console.Clear();

            }
            else
            {
                Console.WriteLine("Ingrese un numero valido");
                Console.ReadKey();
                Console.Clear();
            }
            i++;
        }
    }
}