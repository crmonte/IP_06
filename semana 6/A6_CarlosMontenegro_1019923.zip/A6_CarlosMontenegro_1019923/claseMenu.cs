﻿class claseMenu
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi programa, proyecto 1");
        Console.WriteLine("\nSelecciona el tipo de cafe");
        Console.WriteLine("Menu principal");
        Console.WriteLine("1. Arabigo");
        Console.WriteLine("2. Bourbon");
        Console.WriteLine("3. Pacamara");
        Console.WriteLine("4. Geisha");

        int Seleccionmenu;
        Seleccionmenu= Int32.Parse(Console.ReadLine());

        switch (Seleccionmenu)
        {
            case 1:
                Console.WriteLine("Café Arabigo");
                break;

            case 2:
                Console.WriteLine("Cafe Bourbon");
                break;

            case 3:
                Console.WriteLine("Cafe Pacamara");
                break;

            case 4:
                Console.WriteLine("Cafe Geisha");
                break;
        }

        Console.ReadKey();
    }
    static int stmetodoDummy()
    {
        return 1;
    }
}