﻿class Laboratorio_6
{
    static void Main(string[] args)
    {
        //ejercicio 1
        // se declaran variables 
        int n1=0, n2=0, mult=0, sum=0, res=0;
        double div = 0;


        Console.WriteLine("EJERCICIO 1 - operaciones aritmeticas");

        // se asignan valores a las variables 
        Console.WriteLine("\nIngrese numero 1:");
        n1= Int32.Parse(Console.ReadLine());

        Console.WriteLine("\nIngrese numero 2:");
        n2 = Int32.Parse(Console.ReadLine());

        // se realizan las operaciones indicadas
        sum= n1+ n2;
        res = n1 - n2;
        mult = n1 * n2;
        div = n1 / n2;

        //se imprimen los resultados
        Console.WriteLine("\n"+n1+" + "+n2+" = "+sum);
        Console.WriteLine("\n" + n1 + " - " + n2 + " = " + res);
        Console.WriteLine("\n" + n1 + " * " + n2 + " = " + mult);
        Console.WriteLine("\n" + n1 + " / " + n2 + " = " + div);
        Console.ReadKey();

        //ejercicio 2
        Console.Clear();
        Console.WriteLine("EJERCICIO 2 - operaciones booleanas");
        Console.ReadKey();
        // se evaluan las desigualdades
        if(n1 > n2)
        {
            Console.WriteLine("\n numero 1 es mayor que (>) numero 2");
        }
        else
        {
            Console.WriteLine("\n n1 es menor que (<) numero 2 ");
        }

        if (n1 == n2)
        {
            Console.WriteLine("\nEl numero 1 y numero 2 son iguales");
        }
        else
        {
            Console.WriteLine("\nEl numero 1 y numero 2 no son iguales");
        }


        Console.ReadKey();

        // ejercicio 3

        Console.Clear();
        // se declaran variables
        int num1=0, num2=0, num3=0;   
        double op1=0, op2=0, op3=0, op4=0, a =0;


        Console.WriteLine("EJERCICIO 3 - jerarquia de operaciones");

        // se asignan valores a las variables 
        Console.WriteLine("\nIngrese numero a:");
        num1 = Int32.Parse(Console.ReadLine());

        Console.WriteLine("\nIngrese numero b:");
        num2 = Int32.Parse(Console.ReadLine());

        Console.WriteLine("\nIngrese numero c:");
        num3 = Int32.Parse(Console.ReadLine());

        // se realizan las diversas operaciones
        op1 = (num1 * num2) + num3;
        op2 = num1 * (num2 + num3);
        op3 = num1 / (num2 * num3);
        op4 = ((3 * num1) + (2 * num2)) / Math.Pow(num3, 2);
       

        // se imprimen los resultados
        Console.WriteLine("Resultado de la operacion a * b + c: "+op1);
        Console.WriteLine("Resultado de la operacion a * (b + c): " + op2);
        Console.WriteLine("Resultado de la operacion a /(b * c): " + op3);
        Console.WriteLine("Resultado de la operacion (3a+2b)/c^2: " + op4);

        Console.ReadKey();

        Console.Clear();

        // ejercicio 4
        Console.WriteLine("EJERCICIO 4 - Ecuacion cuadratica");

        double cuad1 = 0, cuad2 = 0, sqrt=0;

        sqrt = (Math.Pow(num2, 2)) - ((4 * num1 * num3));
        if (sqrt < 1)
        {
            Console.WriteLine("Error de valores");
        }
        else
        {
            cuad1 = ((-1*num2) + Math.Sqrt(sqrt)) / (2 * num1);
            cuad2 = ((-1*num2) - Math.Sqrt(sqrt)) / (2 * num1);
            Console.WriteLine("\nValores para x: \nValor x1: "+cuad1+"\nValor x2: "+cuad2);
        }

        Console.ReadKey();
    }
}