﻿class actividad_1
{
    public static double dCantidad1, dCantidad2, dCantidad3; 
    public static string sDenominacion1, sDenominacion2, sDenominacion3;
    public static int contador = 0;
    public static void Main(string[] args)
    {
        // se declaran variables
        string sCantidad1, sCantidad2, sCantidad3;
        

        // titulo de la actividad
        Console.WriteLine("Programa Actividad 1 - Semana 9");

        

        // se solicitan los datos cantidad 1
        Console.WriteLine("Ingrese la cantidad de dinero #1");
        sCantidad1 = Console.ReadLine();

        while (!double.TryParse(sCantidad1, out dCantidad1))
        {
            Console.WriteLine("Ingrese cantidad 1 en formato correcto, ejemplo: 0.00");
            sCantidad1 = Console.ReadLine();
        }

        Console.WriteLine("Ingrese la denominacion #1");
        sDenominacion1 = Console.ReadLine();

        while (sDenominacion1 != "USD" && sDenominacion1 != "GTQ")
        {
            Console.WriteLine("Ingrese una denominacion valida USD o GTQ");
            sDenominacion1 = Console.ReadLine();
        }
        
        calcular(dCantidad1, sDenominacion1);


        // se solicitan los datos cantidad 2
        Console.WriteLine("Ingrese la cantidad de dinero #2");
        sCantidad2 = Console.ReadLine();

        while (!double.TryParse(sCantidad2, out dCantidad2))
        {
            Console.WriteLine("Ingrese cantidad 2 en formato correcto, ejemplo: 0.00");
            sCantidad2 = Console.ReadLine();
        }

        Console.WriteLine("Ingrese la denominacion #2");
        sDenominacion2 = Console.ReadLine();
        while (sDenominacion2 != "USD" && sDenominacion2 != "GTQ")
        {
            Console.WriteLine("Ingrese una denominacion valida USD o GTQ");
            sDenominacion2 = Console.ReadLine();
        }

        calcular(dCantidad2, sDenominacion2);

        // se solicitan los datos cantidad 3
        Console.WriteLine("Ingrese la cantidad de dinero #3");
        sCantidad3 = Console.ReadLine();
        while (!double.TryParse(sCantidad3, out dCantidad3))
        {
            Console.WriteLine("Ingrese cantidad 3 en formato correcto, ejemplo: 0.00");
            sCantidad3 = Console.ReadLine();
        }
        Console.WriteLine("Ingrese la denominacion #3");
        sDenominacion3 = Console.ReadLine();
        while (sDenominacion3 != "USD" && sDenominacion3 != "GTQ")
        {
            Console.WriteLine("Ingrese una denominacion valida USD o GTQ");
            sDenominacion3 = Console.ReadLine();
        }

        //llamada al metodo
        calcular(dCantidad3, sDenominacion3);
        mostrarResultados();

        Console.ReadKey();

    }

    public static void calcular(double cantidad, string denominacion)
    {
        
        contador++;
        if (denominacion == "USD")
        {
            cantidad = cantidad * 7.83;

        }
        switch (contador)
        {
            case 1:
                dCantidad1 = cantidad;
                break;
            case 2:
                dCantidad2 = cantidad;
                break;
            case 3:
                dCantidad3 = cantidad;
                break;
            default:
                break;
        }
    }

    public static void mostrarResultados()
    {
        double mayor, menor, medio;
        //mayor
        if (dCantidad1 > dCantidad2 && dCantidad1 > dCantidad3)
        {
            mayor = dCantidad1;

        }else if (dCantidad2 > dCantidad1 && dCantidad2 > dCantidad3)
        {
            mayor = dCantidad2;
        }
        else
        {
            mayor = dCantidad3;
        }

        //menor
        if (dCantidad1 < dCantidad2 && dCantidad1 < dCantidad3)
        {
            menor = dCantidad1;

        }
        else if (dCantidad2 < dCantidad1 && dCantidad2 < dCantidad3)
        {
            menor = dCantidad2;
        }
        else
        {
            menor = dCantidad3;
        }

        //medio

        if (dCantidad1 > menor && dCantidad1 < mayor)
        {
            medio = dCantidad1;
        }else if(dCantidad2 > menor && dCantidad2 < mayor)
        {
            medio = dCantidad2;
        }
        else
        {
            medio = dCantidad3;
        }

        string resultado = $"{menor} GTQ \n {medio} GTQ \n {mayor} GTQ";
        Console.WriteLine("Resultado: \n"+resultado);
        Console.ReadKey();
    }
}