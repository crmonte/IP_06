﻿class Laboratorio_9
{
    public static string sValor;
    public static float Valor, Total, coddes, segTotal;
    public static void Main(string[] args)
    {
        for (int j = 0; j >= 0; j++)
        {
            int op = 0;
            Console.WriteLine("Ejercicio - Laboratorio 9");
            Console.WriteLine("Ingrese el valor de su compra");
            sValor = Console.ReadLine();

            while (!float.TryParse(sValor, out Valor))
            {
                Console.WriteLine("ingrese un valor valido, ejemplo 0.00");
                sValor = Console.ReadLine();
            }
            for (int i = 0; i >= 0; i++)
            {
                try
                {
                    Console.WriteLine("Posee codigo de descuento?\nIngrese '1' en caso de tener codigo de descuento.\nIngrese '2' en caso de no tener codigo de descuento ");
                    op = Int32.Parse(Console.ReadLine());

                    if (op == 1)
                    {
                        Console.WriteLine("\nIngrese su codigo de descuento");
                        Console.ReadLine();
                        calculoDescuento();
                        coddes = (Total * 5) / 100;
                        segTotal = Total - coddes;
                        Console.WriteLine($"\nSu total a pagar es {segTotal}");
                        break;
                    }
                    else if (op == 2)
                    {
                        calculoDescuento();
                        Console.WriteLine($"\nSu total a pagar es {Total}");

                        break;
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Ingrese una opcion valida");
                }
            }

            Console.ReadKey();
            Console.Clear();
        }
    }
    public static void calculoDescuento()
    {
        float descuento = 0;
        float total = 0;

        if (Valor < 400)
        {
            Total = Valor;
        }

        if (Valor >= 400)
        {
            if (Valor < 1000)
            {
                descuento = (Valor * 7) / 100;
                total = Valor - descuento;
                Total = total;
            }
        }
        
        if (Valor >= 1000)
        {
            if(Valor < 5000) {
                descuento = (Valor * 10) / 100;
                total = Valor - descuento;
                Total = total;
            }
        }

        if (Valor >= 5000)
        {
            if (Valor < 15000)
            {
                descuento = (Valor * 15) / 100;
                total = Valor - descuento;
                Total = total;
            }
        }

        if (Valor >= 15000)
        {
            descuento = (Valor * 25) / 100;
            total = Valor - descuento;
            Total = total;
        }
        
    }
}