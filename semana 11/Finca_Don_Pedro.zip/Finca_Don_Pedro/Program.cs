﻿using Finca_Don_Pedro;

class Finca
{
    static void Main(string[] args)
    {


        // introduccion al menu principal
        Console.WriteLine("                         FINCA DON PEDRO");
        Console.WriteLine("                 Inventario y Tiempos de proceso\n");

        //explicacion de el funcionamiento del programa
        Console.WriteLine("El programa tiene la siguiente funcionalidad:");
        Console.WriteLine("Tiene la funcionalidad de ofrecer informacion al usuario del inventario de cafe\n" +
                          "y los tiempos de produccion del cafe, en sus distintas presentaciones.\n\n");
        Console.WriteLine("                 PRESIONE ENTER PARA CONTINUAR");
        Console.ReadKey();
        Console.Clear();

        //menu principal
        menuPrincipal menu= new menuPrincipal();
        menu.mPrincipal();

        Console.ReadKey();
    }
    
}