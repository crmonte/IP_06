﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finca_Don_Pedro
{
    public class manualUsuario
    {
        public void mUsuario()
        {
            Console.Clear();
            Console.WriteLine("OPCIONES DEL PROGRAMA: ");
            Console.WriteLine("\n   En el programa se puede elegir el tipo de café que se desea consultar \n" +
                              "     entre las siguientes opciones:" +
                              "\n       1. Arábigo" +
                              "\n       2. Robusta" +
                              "\n       3. Bourbon" +
                              "\n       4. Pacamara" +
                              "\n       5. Gueisha\n");
            Console.WriteLine("Al elegir el tipo de café da un mejor control sobre el inventario, lo que es una lista ordenada de los productos" +
                              "que ofrece la empresa.");
            Console.WriteLine("\n\nLuego podra elegir dentro de cada tipo de café la presentacion de la que desea informacion entre:\n" +
                              "     1. Grano\n" +
                              "     2. Molido\n");

            Console.WriteLine("Ademas que al elegir la opcion del cafe y la presentación de la cual desea obtener informacion,\n" +
                              "dentro de la misma pestaña se mostrara el tiempo de producción del mismo");

            Console.WriteLine("\nPROPÓSITO: El propósito del programa es brindar al usuario un acceso facil al inventario y tiempo de producción\n" +
                              "al mismo tiempo ofrecer una navegación fácil entre ventanas para poder un acceso rapido a esta información.\n" +
                              "Además que esta información es detallada segun el tipo de cafe y su presentación, logrando asi un inventario\n" +
                              "detallado y ágil para el usuario.");

            MPoS menuCierre=new MPoS();
            menuCierre.menuSalir();


        }
    }
}
