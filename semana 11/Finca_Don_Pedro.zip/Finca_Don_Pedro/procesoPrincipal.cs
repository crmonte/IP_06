﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finca_Don_Pedro
{
    public class procesoPrincipal
    {
        public void pPrincipal()
        {
            string opcion;
            int op;


            Console.WriteLine("                     PROCESO PRINCIPAL\n");
            Console.WriteLine("\n" +
                              "Ingrese el numero de la opcion que desea consultar.\n");
            Console.WriteLine("1. Arabigo\n" +
                              "2. Robusta \n" +
                              "3. Bourbon \n" +
                              "4. Pacamara\n" +
                              "5. Geisha\n");
            opcion = Console.ReadLine();
            while ((opcion != "1" && opcion != "2" && opcion != "3" && opcion != "4" && opcion != "5") || !Int32.TryParse(opcion, out op))
            {
                Console.WriteLine("Ingrese una opción valida, ejemplo '1'");
                opcion = Console.ReadLine();
            }

            switch (op)
            {
                case 1:
                    break;
                case 2:
                    break;

                case 3:
                    break;

                case 4:
                    break;

                case 5:
                    break;
            }
        }
    }
}
