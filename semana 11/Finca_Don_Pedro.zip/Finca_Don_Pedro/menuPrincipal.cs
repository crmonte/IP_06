﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finca_Don_Pedro
{
    public class menuPrincipal
    {
        public void mPrincipal()
        {
            string opcion;
            int op;

            Console.WriteLine("                     MENÚ PRINCIPAL\n");
            Console.WriteLine("1. Proceso principal (inventario y tiempso de proceso)\n" +
                              "2. Manual de usuario \n" +
                              "3. Créditos \n" +
                              "4. Salir");
            opcion = Console.ReadLine();
            while ((opcion != "1" && opcion != "2" && opcion != "3" && opcion != "4") || !Int32.TryParse(opcion, out op))
            {
                Console.WriteLine("Ingrese una opción valida, ejemplo '1'");
                opcion = Console.ReadLine();
            }
            procesoPrincipal procesoPrincipal=new procesoPrincipal();
            manualUsuario manualUsuario = new manualUsuario();
            creditosPrograma creditosPrograma = new creditosPrograma();
            switch (op)
            {
                case 1:
                    Console.Clear();
                    procesoPrincipal.pPrincipal();
                    break;
                case 2:
                    Console.Clear();
                    manualUsuario.mUsuario();
                    break;

                case 3:
                    Console.Clear();
                    creditosPrograma.creditos();
                    break;

                case 4:
                    Console.WriteLine("\n");
                    Console.WriteLine("PRESIONE DOS VECES ENTER PARA CERRAR EL PROGRAMA");
                    break;
            }
        }
    }
}
